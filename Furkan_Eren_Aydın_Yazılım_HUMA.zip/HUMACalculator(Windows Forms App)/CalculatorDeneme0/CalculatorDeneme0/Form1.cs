﻿using System;
using System.Diagnostics.Eventing.Reader;
using System.Windows.Forms;

namespace CalculatorDeneme0
{
    public partial class Form1 : Form
    {
        //Kullanacağımız değişkenleri belirliyoruz
        //Initializing our variables
        string input = String.Empty;
        string operand1 = string.Empty;
        string operand2 = string.Empty;
        char operation;
        //There are 2 hard problems in Computer Science : cache invalidation and naming things...
        //Şaka bi yana bu değişken matematik işlemlerinden sonra false değerine atanarak txtDialogda sadece 1 tane işlem işareti olmasını sağlıyor
        bool isMathSymbolUsed = false;
        double result = 0.0;

        public Form1()
        {
            InitializeComponent();
        }
        //AppendDigit fonksiyonu kullanıcnın tıkladığı rakamları textBox'a yazmakla görevlidir
        //AppendDigit function takes the number user clicked and writes it to the textBox
        private void AppendDigit(char digit)
        {
            this.txtDialog.Text = "";
            input += digit;
            this.txtDialog.Text += input;
        }
        //ButtonDot fonksiyonu küsürlü sayılar girmek isteyip de uygulamadaki nokta tuşuna bastığınız zaman çalışır
        //ButtonDot function works when you want to enter decimal numbers
        private void buttonDot(object sender, EventArgs e)
        {
            input += ".";
            txtDialog.Text += ".";
        }

        //btnDigit_Click fonksiyonu bütün rakam tuşlarına bağlıdır ve tıkladığınız sayıyı AppendDigit fonksiyonuna gönderir
        //btnDigit_Click function takes the number you clicked and sends it to AppendDigit function
        private void btnDigit_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            char digit = button.Text[0];
            AppendDigit(digit);

        }



        //btnEqualsClick fonksiyonu "=" butonuna basıldığı zaman gerekli değerler sağlandıysa matematik işlemini yapar
        //Teorik olarak bütün matematik işlemleri, kendi ayrı fonksiyonlarına ihtiyaç duymadan burdan yapılabilir ancak gerek kodun temiz gözükmemesi gerek de farklı işlemlerin farklı gereksinimleri olması nedeniyle her matematik işlemine kendi fonksiyonu verilmiştir
        //btnEqualsClick function does the mathematical operation when requirements are meet and user presses "=" button
        //Theoretically all the math operations can be done here without seperate functions. But some math operations require different necessities for them. And also its easier to keep the code more readable and clean this way.
        private void btnEquals_Click(object sender, EventArgs e)
        {
            operand2 = input;
            double num1, num2 = double.NaN;
            double.TryParse(operand1, out num1);
            double.TryParse(operand2, out num2);
            switch (operation)
            {
                case '+':
                    //Basit toplama işlemi
                    result = num1 + num2;
                    //işlem yapıldığı için isMathSymbolUsed false olur ve ekrandan silinir. Bu sayede ekranda 1'den fazla işlem işareti olması önlenir.
                    isMathSymbolUsed = false;
                    break;
                case '-':
                    //Basit çıkartma işlemi
                    result = num1 - num2;
                    isMathSymbolUsed = false;
                    break;
                case '*':
                    //Basit çarpma işlemi
                    result = num1 * num2;
                    isMathSymbolUsed = false;
                    break;
                case '/':
                    //2. sayının 0 olmadığını sorgulayıp bölme işlemini yapar
                    if (num2 != 0)
                    {
                        result = num1 / num2;
                        isMathSymbolUsed = false;
                    }
                    else
                    {
                        txtDialog.Text = "ERROR DIV BY ZER0";
                        return;
                    }
                    break;



            }
            txtDialog.Text = result.ToString();

        }

        //HandleOperator fonksiyonu matematik işlemi butonlarına bağlı olan fonksiyonlardan bir char değişkeni alır ve ona göre operation değişkenini istenen işleme atar
        //HandleOperator function takes a char variable from the functions that are connected to buttons and assigns it to operation variable
        private void HandleOperator(char op)
        {
            operand1 = input;
            operation = op;
            input = string.Empty;
        }
        //button15_Click fonksiyonu AllClear fonksiyonudur, txtDialog'daki yazıyı ve operand1 ve operand2 değişkenlerini boş string'e atar
        //button15_Click function is AllClear function, it changes the text in txtDialog and assigns operand1 and operand2 to empty strings
        private void button15_Click(object sender, EventArgs e)//AC
        {
            txtDialog.Text = "0";
            this.input = string.Empty;
            this.operand1 = string.Empty;
            this.operand2 = string.Empty;

        }
        //buttonAdd fonksiyonu HandleOperator'a '+' char değişkenini gönderir
        //buttonAdd function sends '+' char to HandleOperator function
        private void buttonAdd(object sender, EventArgs e)
        {
            if (!isMathSymbolUsed)
            {
                txtDialog.Text += "+";
                HandleOperator('+');
                isMathSymbolUsed = true;

            }
            else
            {
                return;
            }
        }
        //buttonSubstract fonksiyonu HandleOperator'a '-' char değişkenini gönderir
        //buttonSubstract function sends '-' char to HandleOperator function
        private void buttonSubstract(object sender, EventArgs e)
        {
            if (!isMathSymbolUsed)
            {
                txtDialog.Text += "-";
                HandleOperator('-');
                isMathSymbolUsed = true;
            }
            else
            {
                return;
            }
        }
        //buttonMultiply fonksiyonu HandleOperator'a '*' char değişkenini gönderir
        //buttonMultiply function sends '*' char to HandleOperator function
        private void buttonMultiply(object sender, EventArgs e)
        {
            if (!isMathSymbolUsed)
            {

                txtDialog.Text += "*";
                HandleOperator('*');
                isMathSymbolUsed = true;
            }
            else
            {
                return;
            }
        }
        //buttonDivide fonksiyonu HandleOperator'a '/' char değişkenini gönderir
        //buttonDivide function sends '/' char to HandleOperator function
        private void buttonDivide(object sender, EventArgs e)
        {
            if (!isMathSymbolUsed)
            {
                txtDialog.Text += "/";
                HandleOperator('/');
                isMathSymbolUsed = true;

            }
            else
            {
                return;
            }
        }
        //buttonChangeSign fonksiyonu o anda txtDialog'da olan değeri "-1" ile çarparak değerin işaretini değiştirir
        //buttonChangeSign function multiplies the current value on the txtDialog with "-1" to change its sign

        private void buttonChangeSign(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(input) && input != "0")
            {
                int inputValue = int.Parse(input);
                inputValue = -inputValue;
                input = inputValue.ToString();
                txtDialog.Text = input;
            }


        }

        //btnSqrt_Click fonksiyonu o anda txtDialog'da bulunan sayıyı alır ve karekökünü txtDialog'a yazdırır
        //btnSqrt_Click function takes the number that is currently in the txtDialog and prints the Square root of that number to txtDialog
        private void btnSqrt_Click(object sender, EventArgs e)//sqrt
        {
            if (double.TryParse(txtDialog.Text, out double currentValue) && currentValue >= 0)
            {
                double result = Math.Sqrt(currentValue);
                txtDialog.Text = result.ToString();
            }
            else
            {
                txtDialog.Text = "Invalid Input";
            }
        }

        //buttonSquare_Click fonksiyonu o anda txtDialogda bulunan değerin karesini alır
        //buttonSquare_Click function takes the square of the value that is current in txtDialog
        private void buttonSquare_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtDialog.Text, out double currentValue))
            {
                double result = Math.Pow(currentValue, 2);
                txtDialog.Text = result.ToString();
            }
            else
            {
                txtDialog.Text = "Invalid Input";
            }
        }
        //buttonSinus_Click fonksiyonu o anda txtDialogda bulunan değerin sinüsünü alır
        //buttonSinus_Click function takes the sinus of the value that is current in txtDialog
        private void buttonSinus_Click(object sender, EventArgs e)
        {

            if (double.TryParse(txtDialog.Text, out double currentValue))
            {
                //txtDialog'daki değeri π/180 ile çarparak radyan birimine dönüştürür ve ardından trigonometrik işlemi yapar
                double radians = currentValue * (Math.PI / 180);

                double result = Math.Sin(radians);
                txtDialog.Text = result.ToString();
            }
            else
            {
                txtDialog.Text = "Invalid Input";
            }
        }
        //buttonCosinus_Click fonksiyonu o anda txtDialogda bulunan değerin kosinüsünü alır
        //buttonCosinus_Click function takes the cosinus of the value that is current in txtDialog

        private void buttonCosinus_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtDialog.Text, out double currentValue))
            {
                //txtDialog'daki değeri π/180 ile çarparak radyan birimine dönüştürür ve ardından trigonometrik işlemi yapar
                double radians = currentValue * (Math.PI / 180);
                double result = Math.Cos(radians);
                txtDialog.Text = result.ToString();
            }
            else
            {
                txtDialog.Text = "Invalid Input";
            }
        }
        //buttonTanjant_Click fonksiyonu o anda txtDialogda bulunan değerin tanjantını alır
        //buttonTanjant_Click function takes the tangent of the value that is current in txtDialog
        private void buttonTanjant_Click(object sender, EventArgs e)
        {
            //TryParse ile txtDialog'daki değeri alıp double'a dönüştürür
            if (double.TryParse(txtDialog.Text, out double currentValue))
            {
                //txtDialog'daki değeri π/180 ile çarparak radyan birimine dönüştürür ve ardından trigonometrik işlemi yapar
                double radians = currentValue * (Math.PI / 180);
                double result = Math.Tan(radians);
                txtDialog.Text = result.ToString();
            }
            else
            {
                txtDialog.Text = "Invalid Input";
            }
        }

        private void buttonFactorial_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtDialog.Text, out double currentValue))
            {
                //faktöriyel fonksiyonuna currentValue'yi yollayarak faktöriyel alır
                double result = factorial(currentValue);
                txtDialog.Text = result.ToString();
            }
            else
            {
                txtDialog.Text = "Invalid Input";
            }
        }
        //Basit bi faktöriyel alma fonksiyonu, 0 ise 1 döndürür değilse sayının faktöriyelini döndürür
        long factorial(double n)
        {
            if (n == 0)
            {
                return 1;
            }

            long factorial = 1;
            for (int i = 1; i <= n; i++)
            {
                factorial *= i;
            }

            return factorial;
        }


        //Ekrandaki ufak sürprizi farketmenize olanak sağlar
        private void Form1_Load(object sender, EventArgs e)
        {
            if (ClientSize.Width >= 370)
            {
                textBox.Text = "Teşekkürler :)";
            }
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }
    }
}
