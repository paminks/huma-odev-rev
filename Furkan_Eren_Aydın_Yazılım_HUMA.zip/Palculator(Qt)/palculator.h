#ifndef PALCULATOR_H
#define PALCULATOR_H

#include <QMainWindow>
#include <aboutinfo.h>

QT_BEGIN_NAMESPACE
namespace Ui { class Palculator; }
QT_END_NAMESPACE

class Palculator : public QMainWindow
{
    Q_OBJECT

public:
    Palculator(QWidget *parent = nullptr);
    ~Palculator();

private:
    Ui::Palculator *ui;


private slots:
    void NumPressed();
    void MathButtonPressed();
    void EqualButton();
    void ChangeNumberSign();
    void ClearPalc();
    void on_actionAbout_Palculator_triggered();
};
#endif // PALCULATOR_H
