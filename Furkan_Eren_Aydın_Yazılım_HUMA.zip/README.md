FURKAN EREN AYDIN HUMA ARAYUZ TASARIM ODEVI

Yönergede belirtildiği gibi basit matematik işlemlerini yapabilen bir hesap makinesi tasarladım. 
Yazdığım kodu satır satır yorumladım. 
sinus cosinus tanjant sqrt x² gibi işlemlerde neden ayrı fonksiyonlar kullandığımı kodun yorum satırlarında açıkladım. 

Ayrı olarak aynı uygulamanın QT Framework'ünde yaptığım versiyonunu da dosyaya ekledim. 
Diğer projelerime göz atmak için : 
[GitHub] https://github.com/paminks
[Itch.io] https://paminks.itch.io