#include "aboutinfo.h"
#include "ui_aboutinfo.h"

AboutInfo::AboutInfo(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AboutInfo)
{
    ui->setupUi(this);
}

AboutInfo::~AboutInfo()
{
    delete ui;
}
