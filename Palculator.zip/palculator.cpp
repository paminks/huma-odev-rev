#include "palculator.h"
#include "ui_palculator.h"

double calcValue = 0.0;
bool divTrigger = false;
bool multTrigger = false;
bool addTrigger = false;
bool subTrigger = false;
bool clearTrigger = false;

Palculator::Palculator(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Palculator)
{
    ui->setupUi(this);
    ui->Display->setText(QString::number(calcValue));
    QPushButton *numButtons[10];
    for(int i=0; i<10;i++)
    {
        QString butName = "Button"+ QString::number(i);
        numButtons[i] = Palculator::findChild<QPushButton *>(butName);
        connect(numButtons[i], SIGNAL(released()), this, SLOT(NumPressed()));
    }
    connect(ui->Add, SIGNAL(released()), this, SLOT(MathButtonPressed()));
    connect(ui->Minus, SIGNAL(released()), this, SLOT(MathButtonPressed()));
    connect(ui->Multiply, SIGNAL(released()), this, SLOT(MathButtonPressed()));
    connect(ui->Divide, SIGNAL(released()), this, SLOT(MathButtonPressed()));


    connect(ui->Equals, SIGNAL(released()), this, SLOT(EqualButton()));

    connect(ui->PlusMinus, SIGNAL(released()), this, SLOT(ChangeNumberSign()));

    connect(ui->Clear, SIGNAL(released()), this, SLOT(ClearPalc()));

}

Palculator::~Palculator()
{
    delete ui;
}

void Palculator::NumPressed()
{
    QPushButton *button = (QPushButton *)sender();
    QString butVal = button->text();
    QString displayVal = ui->Display->text();
    if((displayVal.toDouble()==0) || (displayVal.toDouble() == 0.0))
    {
        ui->Display->setText(butVal);
    }else
    {
        QString newVal = displayVal + butVal;
        double dblNewVal = newVal.toDouble();
        ui->Display->setText(QString::number(dblNewVal, 'g', 16));
    }
}

void Palculator::MathButtonPressed()
{
    divTrigger=false;
    multTrigger = false;
    addTrigger = false;
    subTrigger = false;
    clearTrigger = false;
    QString displayVal = ui->Display->text();
    calcValue = displayVal.toDouble();
    QPushButton *button = (QPushButton *)sender();
    QString butVal = button->text();
    if(QString::compare(butVal, "/", Qt::CaseInsensitive) == 0)
    {
        divTrigger = true;
    } else if(QString::compare(butVal, "*", Qt::CaseInsensitive) == 0)
    {
        multTrigger = true;
    } else if(QString::compare(butVal, "+", Qt::CaseInsensitive) == 0)
    {
        addTrigger = true;
    } else if(QString::compare(butVal, "-", Qt::CaseInsensitive) == 0)
    {
        subTrigger = true;
    } else if(QString::compare(butVal, "AC", Qt::CaseInsensitive) ==0)
    {
        clearTrigger = true;
    }
    ui->Display->setText("");


}

void Palculator::EqualButton()
{
    double solution =0.0;
    QString displayVal = ui->Display->text();
    double dblDisplayVal = displayVal.toDouble();
    if(addTrigger || subTrigger || multTrigger || divTrigger)
    {
        if(addTrigger)
        {
            solution = calcValue + dblDisplayVal;
        } else if(subTrigger)
        {
            solution = calcValue - dblDisplayVal;
        } else if(multTrigger)
        {
            solution = calcValue * dblDisplayVal;
        } else if(divTrigger)
        {
            solution = calcValue / dblDisplayVal;
        }
    }else if(clearTrigger)
    {
        calcValue=0;
        solution =0.0;
    }
    ui->Display->setText(QString::number(solution));
}



void Palculator::ChangeNumberSign()
{
    QString displayVal = ui->Display->text();
    QRegExp reg("[-]?[0-9.]*");
    if(reg.exactMatch(displayVal))
    {
        double dblDisplayVal = displayVal.toDouble();
        double dblDisplayValSign = -1 * dblDisplayVal;
        ui->Display->setText(QString::number(dblDisplayValSign));
    }
}

void Palculator::ClearPalc()
{
    ui->Display->setText("0");
}

void Palculator::on_actionAbout_Palculator_triggered()
{
    AboutInfo AboutInfo;
    AboutInfo.setModal(true);
    AboutInfo.exec();

}

