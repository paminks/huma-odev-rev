#ifndef ABOUTINFO_H
#define ABOUTINFO_H

#include <QDialog>

namespace Ui {
class AboutInfo;
}

class AboutInfo : public QDialog
{
    Q_OBJECT

public:
    explicit AboutInfo(QWidget *parent = nullptr);
    ~AboutInfo();

private:
    Ui::AboutInfo *ui;
};

#endif // ABOUTINFO_H
